import React from "react";
import "./Sidebar.css";

const Result = () => {
    return (
        <>
           <div className="resultpage">
                
           </div>
        </>
    );
};

export default Result;